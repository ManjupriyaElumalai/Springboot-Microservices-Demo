package com.springboot.nameMicroserviceCBdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootNameMicroserviceCircuitbreakerdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
