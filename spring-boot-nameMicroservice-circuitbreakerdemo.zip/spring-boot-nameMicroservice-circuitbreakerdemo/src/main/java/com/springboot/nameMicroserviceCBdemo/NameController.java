package com.springboot.nameMicroserviceCBdemo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/name")
public class NameController {

	@GetMapping("/employee")
	public String getName() {
		return "employee name from name Api";
	}
}
