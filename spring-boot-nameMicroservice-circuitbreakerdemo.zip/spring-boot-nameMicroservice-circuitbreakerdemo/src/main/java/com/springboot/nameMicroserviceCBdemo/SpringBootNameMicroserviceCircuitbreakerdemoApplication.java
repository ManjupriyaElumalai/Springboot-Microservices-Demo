package com.springboot.nameMicroserviceCBdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootNameMicroserviceCircuitbreakerdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootNameMicroserviceCircuitbreakerdemoApplication.class, args);
	}

}
