package com.springboot.salaryMicroserviceCBdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSalaryMicroserviceCircuitbreakerdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSalaryMicroserviceCircuitbreakerdemoApplication.class, args);
	}

}
