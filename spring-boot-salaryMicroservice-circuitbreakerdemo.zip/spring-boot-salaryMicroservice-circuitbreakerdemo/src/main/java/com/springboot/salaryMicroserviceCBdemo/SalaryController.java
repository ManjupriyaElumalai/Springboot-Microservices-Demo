package com.springboot.salaryMicroserviceCBdemo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/salary")
public class SalaryController {

	@GetMapping("/employee")
	public int getSalary() {
		return 10000;
	}
}
