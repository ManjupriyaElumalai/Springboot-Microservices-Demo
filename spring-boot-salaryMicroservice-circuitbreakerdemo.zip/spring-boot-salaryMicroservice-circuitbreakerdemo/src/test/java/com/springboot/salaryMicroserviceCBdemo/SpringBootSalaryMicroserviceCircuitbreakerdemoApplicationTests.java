package com.springboot.salaryMicroserviceCBdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSalaryMicroserviceCircuitbreakerdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
